from game_data import data
import random
from art import logo, vs
from replit import clear

#generate a random account from the data 
def get_random_account():
    '''get data from random account'''
    return random.choice(data)

#format account data into printable format
def format_data(account):
    '''format account into printable format: name, description and country '''
    name = account["name"]
    description = account["description"]
    country = account["country"]
    # print(f'{name}: follower count:{account["follower_count"]}')
    return f'{name}, a {description} from {country}'

#create a function to check the user's guess
def check_answer(guess, a_follower_count, b_follower_count):
    '''check the user's answer and tell if it is right or wrong'''
    if a_follower_count > b_follower_count:
        return guess == "a"
    else:
        return guess == "b"

def game():
    print(logo)
    score = 0
    game_should_continue = True
    
    while game_should_continue:
        account_a = get_random_account()
        account_b = get_random_account()

        while account_a == account_b:
            account_b = get_random_account()

        print(f"Compare A: {format_data(account_a)}.")
        print(vs)
        print(f"Compare B: {format_data(account_b)}.")

        #ask user for a guess
        guess = input("Who has more followers? Type A or B: ").lower()
        a_follower_count = account_a["follower_count"]
        b_follower_count = account_b["follower_count"]

        #check if the user is correct
        is_correct = check_answer(guess, a_follower_count, b_follower_count)

        clear()
        print(logo)
        if is_correct:
            score += 1
            print(f"You are right! Current score: {score}")
        else: 
            game_should_continue = False
            print(f"Sorry, that's wrong. Final score: {score}")
game()

